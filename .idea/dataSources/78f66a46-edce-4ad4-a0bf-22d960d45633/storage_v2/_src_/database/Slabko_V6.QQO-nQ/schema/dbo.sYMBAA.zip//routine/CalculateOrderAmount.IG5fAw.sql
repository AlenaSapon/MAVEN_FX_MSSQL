CREATE procedure CalculateOrderAmount
@synt_code int,
@rc decimal(10,2) =null OUT
as 
begin
set @rc= isnull((select sum(isnull(amount, 0.00)) from ORDERS_DESC where SYNT_CODE=@synt_code),0.00)
return @rc 
end
go

